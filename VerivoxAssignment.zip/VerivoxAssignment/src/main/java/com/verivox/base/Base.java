//*******************************************************************************************
// Class Name : Base
//Description: This Class contains @BeforeClass and @AfterClass annotations
//			   @BeforeClass : This executes before all tests to check on
//                            Browser (will fetch from configuration property file)
//                            Navigate to URL (will fetch from configuration property file)
//                            Accept the banner.
//             @AfterClass : This executes post all tests to close all browsers script has 
//							  opened and to kill driver object
//
//********************************************************************************************


package com.verivox.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Base {

	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static WebDriverWait wait;
	public static String browser;

	@BeforeClass
	public void setup() {

		
		if (driver == null) {

			try {
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\Config.properties");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			try {
				config.load(fis);
			} catch (IOException e) {

				e.printStackTrace();
			}

			if (System.getenv("browser") != null && !System.getenv("browser").isEmpty()) {

				browser = System.getenv("browser");
			} else {

				browser = config.getProperty("browser");

			}

			config.setProperty("browser", browser);

			if (config.getProperty("browser").equals("firefox")) {
				System.setProperty("webdriver.gecko.driver",
						System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe");

				driver = new FirefoxDriver();

			} else if (config.getProperty("browser").equals("chrome")) {
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe");
				driver = new ChromeDriver();

			} else if (config.getProperty("browser").equals("ie")) {

				System.setProperty("webdriver.ie.driver",
						System.getProperty("user.dir") + "\\Drivers\\IEDriverServer.exe");
				driver = new InternetExplorerDriver();

			}

			driver.get(config.getProperty("testsiteurl"));
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
					TimeUnit.SECONDS);
			wait = new WebDriverWait(driver, 10);

			WebElement acc_cookie = driver.findElement(By.xpath("//*[@id=\"uc-btn-accept-banner\" and @class='gdpr-button gdpr-accept-all first-layer']"));
			new WebDriverWait(driver,180).until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"uc-btn-accept-banner\" and @class='gdpr-button gdpr-accept-all first-layer']")));
					acc_cookie.click();
			

			
		}

	}

//to finish the execution

	@AfterClass

	public void tearDown() {
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}
}