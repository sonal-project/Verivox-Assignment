//*******************************************************************************************
// Class Name : DSL_searchResults
//Description:  This class contains objects , locators and coding logic required for
//              validations on page which displays Search Results of tariffs
//              This class extends Base class
//
//********************************************************************************************

package com.verivox.Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.verivox.base.Base;

public class DSL_searchResults extends Base {

	// Declaring public variables to be access outside this class
	public int intETC;
	public int intTDC;
	public int intIndex = 1;
	public int intTariff;
	public boolean blnVerify_20moreResBtn_display = true;

	// Declaring Explicit wait for certain conditions to be satisfied
	WebDriverWait wait = new WebDriverWait(driver, 30);
	

	// Defining locators
	List<WebElement> ListZA = driver.findElements(By.xpath("//*[@class='button-primary w-100 ng-star-inserted']"));
	WebElement ZA = ListZA.get(intTariff);
	
	
	//Verify that we are on expected ;tariff result list' page
	public void testValidate_page(){
		String strTitle = driver.getTitle();
		String strExpTitle= "DSL-Preisvergleich aller DSL-Anbieter in Deutschland";
		Assert.assertTrue(strTitle.equalsIgnoreCase(strExpTitle),"'Tariff Result List page is not displayed.");
	}
	
	
	// Explicit wait declared for Zum Angebot button
	public void waitforZA_Btn(int intTariff) {
		
		List<WebElement> ListZA = driver.findElements(By.xpath("//*[@class='button-primary w-100 ng-star-inserted']"));
		WebElement ZA = ListZA.get(intTariff);
		wait.until(ExpectedConditions.elementToBeClickable(ZA));
	}
	
	//Returning the selected tariff's name to verify on the next page
	public String testSelected_TariffPage(int intTariff) {
		
		List<WebElement> SelectedOffer = driver.findElements(By.xpath("(//div[contains(@class,'headline-short-name')])"));
		
		String strOffer = SelectedOffer.get(intTariff).getText();
		System.out.println("Selected offer is : " +strOffer);
	
	 return strOffer;
	}

	// Click method for Zum Angebot button

	public void zumAngebot_Btn_Click(int intTariff) {
		List<WebElement> ListZA = driver.findElements(By.xpath("//*[@class='button-primary w-100 ng-star-inserted']"));
		WebElement ZA = ListZA.get(intTariff);
		ZA.click();
	}
	
	// Method to capture the value of price on Search Results page and pass it to
	// another class for comparison
	public String get_Price_SR(int intTariff) {

		List<WebElement> price_SR = driver.findElements(By.xpath("//*[@class='position-relative large mb-2']"));
		String strPrice = price_SR.get(intTariff).getText();
		
		return strPrice;
	}

	
	// Method to capture the Internetandcable on Search Results page and pass it to
	// another class for comparison
	public String get_Internetandcable(int intTariff) {
		List<WebElement> internetandCable_SR = driver
				.findElements(By.xpath("//*[starts-with(@class,'headline-short-name')]"));
		String strHS = internetandCable_SR.get(intTariff).getText();
		System.out.println("Internet and cable:"+strHS);
		return strHS;
	}

	// Get the value of tarifs from Ermittelte Tarife section
	public void ermittelte_Tarife_Count() {
		String TDcount = driver.findElement(By.xpath("//h2[@class='summary-tariff']")).getText();
		String[] strS = TDcount.split(" ");
		String strS1 = strS[0];
		intETC = Integer.parseInt(strS1);
		System.out.println("The number of Tariffs displayed in Ermittelte Tarife section: " + intETC);
	}

	// Explicit wait declared for 20 Weitere Tarife laden button
	public void waitfor_20WTL() {
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//button[contains(text(),'weitere tarife laden')]")));
		
	}

	// Get the values for download speed for tariffs on the first page and compare if they are
		// equal to or more than 100 MBPS or not
	public boolean dlSpeed_LandingPage()
	{
	int intCounter = 0;
	List<WebElement> download = driver.findElements(By.xpath("//*[text()='Ermittelte Tarife']/following-sibling::div//img[@class='download-icon']//following::b[1]"));
	for (; intCounter < download.size(); intCounter++) {
		String s = download.get(intCounter).getText();
		int intS1 = Integer.parseInt(s.replace(".", ""));
		System.out.println("Download speed:" + intS1);
	
		if (intS1 >= 100)
		{
			continue;
		}
		else
			return false;
		}
	return true;

	}
	
		// Get the value of tariffs loaded on the page once the 20 Weitere Tarife laden
		public void total_Tarif_Loaded_Count() {
			List<WebElement> TotalTarifDetails = driver.findElements(By.xpath(
					"//*[text()='Ermittelte Tarife']/following-sibling::div//button[@class='button-secondary w-100 tariff-details-toggle']"));
			intTDC = TotalTarifDetails.size();
			System.out.println("The total number of Tariffs loaded on the page are: " + intTDC);
		}
	
		
		// Get the values for download speed for all tariffs and compare if they are toggle
		// equal to or more than 100 MBPS or not
		// validate the button is not visible anymore once all tariffs are displayed
		//Final 'weitere tarife laden' button does displays the expected number of tariffs remaining
		
		public boolean load20moreRes_Btn_Click() throws InterruptedException {
		
		int intCounter = 0;
		boolean blnResult = true;
		int intCalCount = 0;
		String strRemainCount,strButtonText;
		
		//locator for 'weitere tarife laden' button
		WebElement Load20moreRes = driver.findElement(By.xpath("//button[contains(text(),'weitere tarife laden')]"));
		
		do {
			List<WebElement> download = driver.findElements(By.xpath(
					"//*[text()='Ermittelte Tarife']/following-sibling::div//img[@class='download-icon']//following::b[1]"));
			
			// Verify Speed
			for (; intCounter < download.size(); intCounter++) {
				String s = download.get(intCounter).getText();
				int intS1 = Integer.parseInt(s.replace(".", ""));
				if (intS1 >= 100)
				{
					continue;
				}
				else
					return false;
			}
			
			//Check if the button 'weitere tarife laden' is not visible once all tariffs are displayed
			//Final 'weitere tarife laden' button does displays the expected number of tariffs remaining
			
			try {
				if (Load20moreRes.isDisplayed()) {
					
					intCalCount = intETC - intCounter ;
					 System.out.println("Expected number of Tariffs Remaining to display: "+intCalCount);
					 
					 if (intCalCount <= 20){ 
						    strButtonText = Load20moreRes.getText(); 
							System.out.println("Final 'weitere tarife laden' button's Text :" +strButtonText);
							strRemainCount = Integer.toString(intCalCount);
							Assert.assertTrue(strButtonText.contains(strRemainCount),"'weitere tarife laden' button doesn't displays "
									+ "the expected number of tariffs remaining");
							
					 }
					 
					Load20moreRes.click();
					Thread.sleep(7000);
					System.out.println("Clicked on '20 Weitere Tarife laden' to load more results");
					
				}

			} catch (Exception e) {
				blnResult = false;
				blnVerify_20moreResBtn_display=blnResult;
				System.out.println("'Weitere Tarife laden' button is no longer displayed");
			}

		} while (blnResult);
		return true;
	}

}
