//*******************************************************************************************
// Class Name : DSL_Tarifdetails
//Description:  This class contains objects , locators and coding logic required for
//              validations on selected tariffs detail page
//              This class extends Base class
//
//********************************************************************************************


package com.verivox.Pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import com.verivox.base.Base;

public class DSL_Tarifdetails extends Base {
	
	// declaring variables
	public boolean blnCompare;
	String strPrice_TR_name;


	
	// Declaring locators
	WebElement In5min_t = driver.findElement(By.xpath("//*[@class='responsive-label-txt offer-page-cta' and @data-description='firstAvailabilityCheckButton']"));
	WebElement In5min_m = driver.findElement(By.xpath("//*[@class='responsive-label-txt offer-page-cta' and @data-description='secondAvailabilityCheckButton']"));
	WebElement price_TR = driver.findElement(By.xpath("//div[@class='summary-tariff-content flex']/div[1]/div"));
	WebElement InternetandCable = driver.findElement(By.xpath("//h3[@class='group-header']"));
	WebElement Vendorstation = driver.findElement(By.xpath("//div[@class='option-description hardware-tab']"));
	WebElement Tarifkosten = driver.findElement(By.xpath("//table[@class='costs-table']//*[contains(text(),'Tarifkosten')]"));
	WebElement Vorteile = driver.findElement(By.xpath("//table[@class='costs-table']//*[contains(text(),'Vorteile')]"));
	WebElement Durchschnittspreis = driver.findElement(By.xpath("//*[@class='average-price']//*[contains(text(),'Durchschnittspreis')]"));
	WebElement Durchschnittspreis_price = driver.findElement(By.xpath("//*[@class='average-price-naming cost-name']//following::td[1]"));
	WebElement internet_hw = driver.findElement(By.xpath("//*[contains(text(),'Internet-Hardware')]//following::span[1]"));
	WebElement AvgPrice = driver.findElement(By.xpath("//*[@class='average-price']"));
	WebElement PageHeader = driver.findElement(By.xpath("//h1[contains(text(),'Angebot')]"));
	
			
	
	// Declaring explicit wait until both 'In 5 Minuten online wechseln' buttons are
	// displayed
	public void waitfor_In5min_Btn() {
		wait.until(ExpectedConditions.elementToBeClickable(In5min_m));
		wait.until(ExpectedConditions.elementToBeClickable(In5min_m));
	}

	//Verify Corresponding offer page for the selected tariff is displayed
	public void check_PageIsExpected(String strTariff) {
		
		String strPageHeader = PageHeader.getText();
		Assert.assertTrue(strPageHeader.contains(strTariff),"The Corresponding offer page of the Selected Tariff is not displayed.");		
		
	}
	
	// Checking if both 'In 5 Minuten online wechseln' buttons are displayed or not
	public boolean check_Both_Btns() {
		
		boolean blnB1 = In5min_t.isDisplayed();
		boolean blnB2 = In5min_m.isDisplayed();

		if (blnB1 == true && blnB2 == true) {
			return true;
		} else {
			return false;
		}
	}

	// Fetching the contents from the search results page and comparing it with the
	// tariff details page to check if the details are displayed for the same tariff
	public void selected_Tariff(String strH1, String strP1) {
		strPrice_TR_name = price_TR.getText();
		System.out.println("Price in selected tariff details page: " + strPrice_TR_name);
		String InternetandCable_name = InternetandCable.getText();
		System.out.println("Internet and cable in selected tariff details page: " + InternetandCable_name);

		// checking if radio btn or checkbox and proceeding according to that

		WebElement rbtn_cbox = driver
				.findElement(By.xpath("//*[contains(text(),'Internet-Hardware')]//following::input[1]"));
		String strGettype = rbtn_cbox.getAttribute("type");
		String radio = "radio";
		boolean blnVS_btn = false;

		Actions action = new Actions(driver);
		
		if (strGettype.equalsIgnoreCase(radio)) {
			action.moveToElement(rbtn_cbox).click().build().perform();	
			blnVS_btn = true;
			
		} else {
			action.moveToElement(rbtn_cbox).click().build().perform();	
			blnVS_btn = true;
		}

		String strInternet_hw_options = internet_hw.getText();
		String  strAveragePrice = AvgPrice.getText();

		Assert.assertTrue(blnVS_btn,"There is no RadioButton OR Checkbox under 'Internet-hardware section'"); // radiobutton or checkbox
		Assert.assertTrue(strInternet_hw_options != null, "There are no hardware options"); // internet and cable
		Assert.assertTrue(strH1.equalsIgnoreCase(InternetandCable_name), "The Internet cable is different from the Search results page");
		Assert.assertTrue(strP1.equalsIgnoreCase(strPrice_TR_name), "The price displayed is different from the Search results page");
		Assert.assertTrue(strAveragePrice.contains(strPrice_TR_name),"The Average price displayed is different from the Price on Search results page");
		
	}

	// Validating the fixed contents for the tariff details page
	public void verify_Page_FixedContents() {
		
	WebElement Hardware = driver.findElement(By.xpath("//table[@class='costs-table']//*[contains(text(),'Hardware')]"));
	//WebElement Durchschnittspreis_price = driver.findElement(By.xpath("//*[@class='average-price-naming cost-name']//following::td[1]"));
	
		List<String> list = new ArrayList<String>();
		list.add("Tarifkosten");
		list.add("Hardware");
		list.add("Vorteile");
		list.add("Durchschnittspreis");
		list.add(strPrice_TR_name);
		System.out.println("Expected fixed page contents: " + list);

		List<String> listTemp = new ArrayList<String>();
		listTemp.add(Tarifkosten.getText());
		listTemp.add(Hardware.getText());
		listTemp.add(Vorteile.getText());
		listTemp.add(Durchschnittspreis.getText());
		listTemp.add(Durchschnittspreis_price.getText());
		System.out.println("Actual fixed page contents: " + listTemp);

		blnCompare = list.containsAll(listTemp);
		System.out.println("Comparision result of expected and actual is: " + blnCompare);
		
		
		
	}
}
