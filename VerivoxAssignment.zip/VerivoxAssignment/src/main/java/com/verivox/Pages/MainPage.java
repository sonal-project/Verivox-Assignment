//*******************************************************************************************
// Class Name : MainPage
//Description:  This class contains objects , locators and coding logic required for
//              validations on main page of the Verivox website
//              This class extends Base class
//
//********************************************************************************************

package com.verivox.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.verivox.base.Base;

public class MainPage extends Base

{
	// Declaring Explicit wait for certain conditions
	WebDriverWait wait = new WebDriverWait(driver, 30);

	// Defining locators
	WebElement DSL = driver.findElement(By.xpath("//span[contains(text(),'DSL')]"));
	WebElement IhreVorwahl_txtbox = driver.findElement(By.xpath("//input[@name='phonePrefix']"));
	WebElement MBPS_Selection = driver.findElement(By.xpath("//label[contains(@id,'-calc-dsl-option-3')]"));
	WebElement JetztV_btn = driver
			  .findElement(By.xpath("//div[@class='calc-toggles toggle-two-lines']//following::button[1]"));
			  

	// Chooses tab 'DSL'
	public void clickDSL_Btn() {
		wait.until(ExpectedConditions.elementToBeClickable(DSL));

		DSL.click();

	}

	// Sends value "030" to 'Ihre Vorwahl' text box
	public void enterIV_Txt() {

		IhreVorwahl_txtbox.sendKeys("030");
	}

	// Select '100 MBPS' option
	public void MBPS_Select() {
		wait.until(ExpectedConditions.elementToBeClickable(MBPS_Selection));
		MBPS_Selection.click();
	}

	// Click Jetzt Vergleichen button
	public void clickJV_Btn() {
		wait.until(ExpectedConditions.elementToBeClickable(JetztV_btn));
		JetztV_btn.click();
	}

}
