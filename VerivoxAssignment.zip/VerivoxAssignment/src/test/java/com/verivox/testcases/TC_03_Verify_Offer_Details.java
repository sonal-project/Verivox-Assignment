
//***********************************************************************************************
// Test Name & Class Name : TC_03_Verify_Offer_Details.java
//
// Description: After navigating to DSL page with given data, Selecting Internet tariff 
//             from listed tariff and perform given validation on 
//             tariff detail page
//
// Data used : Area code: 030 , Bandwidth Option: 100 Mbit/s
//
// TC_03_Verify_Offer_Details.java extends Base class : To selected needed browser and
//                                           killing driver instance post execution
//
// Parameter : This Case will execute for 2 tariffs
//    		  Using DataProvider Annotation(passing tariffs indices for selection and validations)
//
// Validations performed: 1.After entering required data and clicking on 'Jetzt vergleichen'
//                         button, needed page with available tariffs are displayed 
//                       2. Click on 'Zum Angebot' button to select tariff
//						 3. Corresponding offer page for selected tariff should get displayed
//                       4. Verify that both 'In 5 Minuten online wechseln' buttons are displayed
//						 5. Verify details for selected tariff as per the outlined page contents 
//                          given in screenshot 5
//                       6. Parameterized using 'DataProvider' annotation to perform above
//                          validations for 2 different tariffs
//************************************************************************************************


package com.verivox.testcases;


import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.verivox.Pages.DSL_Tarifdetails;
import com.verivox.Pages.DSL_searchResults;
import com.verivox.Pages.MainPage;
import com.verivox.base.Base;


@Test(dataProvider="getData")
public class TC_03_Verify_Offer_Details extends Base {

	public void verify_Ofr_Dtls(int intTariffCnt)

	
	{
		int intTariff = intTariffCnt;
				
		if (intTariff > 0) {
			wait = new WebDriverWait(driver, 60);
			Base bs = new Base();
			bs.tearDown();
			bs.setup();			
			
		}
			
		
		// Creating object of MainPage class and calling it's methods
		//These will help navigating till page that lists the available tariffs for selection
		MainPage mp = new MainPage();
		mp.clickDSL_Btn();
		mp.enterIV_Txt();
		mp.MBPS_Select();
		mp.clickJV_Btn();

		// Creating object of DSL_searchResults class and calling it's methods
		
		System.out.println("TestCase is running for data:"+intTariff);
		// This will help script to Explicitly wait for 'Zum Angebot' button to get loaded
		DSL_searchResults dsr = new DSL_searchResults();
		dsr.waitforZA_Btn(intTariff);
		
		
		//Verify that we are on expected ;tariff result list' page
		dsr.testValidate_page();
		
		
		//Collecting Selected Tariff's name to validate it on next details page
		String strSelectedTariff = dsr.testSelected_TariffPage(intTariff);
		System.out.println("Selected tariff name:"+strSelectedTariff);
		
		//Collecting all the tariff headlines
		String strH1 = dsr.get_Internetandcable(intTariff);
		
		//Collecting all Prices
		String strP1 = dsr.get_Price_SR(intTariff);
		
		//Selecting the required Tariff
		dsr.zumAngebot_Btn_Click(intTariff);

		// Creating object of DSL_Tarifdetails class and calling it's methods
		DSL_Tarifdetails dtd = new DSL_Tarifdetails();
		dtd.waitfor_In5min_Btn();
		
		
		//Verify Corresponding offer page for the selected tariff is displayed	
		//passing parameter of selected tariff's name to validate page header
		dtd.check_PageIsExpected(strSelectedTariff);

		// Verify that the offer page displays with both 'In 5 Minuten online wechseln'
		// buttons

		//dtd.check_Both_Btns();
		boolean blnB = dtd.check_Both_Btns();

		if (blnB) {
			System.out.println("Both 'In 5 Minuten online wechseln' buttons are displayed");
			Assert.assertTrue(true);
		} else {
			System.out.println("Both 'In 5 Minuten online wechseln' buttons are NOT displayed");
			Assert.assertTrue(false);
		}

		// Verify that the expected page contents and tariff details for selected
		// tariff as per the outlined page contents in screenshot 5

		dtd.selected_Tariff(strH1, strP1);
		

		dtd.verify_Page_FixedContents();
		Assert.assertTrue(dtd.blnCompare==true, "Page contents are not as expected");

	}
	


//**********************************************************************************************
// DataProvider Annotation to run this test for multiple Tariffs
// Data given is the indices of the all tariffs listed on tariff list page
// Currently i have passes indices of 1st and 5th Tariff listed on a page
//These indices are used for selection and all expected validations	
//**********************************************************************************************	

@DataProvider

	public Object[][] getData() 
	{
	
	//Rows stands for how many different data types test should run (here we are passing integer)
	// Here we are passing 'number of tariffs' for which we want to run this test
	Object[][] data = new Object[2][1];
	data[0][0] = 0;
	data[1][0] = 4;
			
	return data;
	
	
	}

}


