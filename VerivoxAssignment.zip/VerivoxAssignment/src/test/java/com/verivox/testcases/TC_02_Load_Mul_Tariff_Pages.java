
//*******************************************************************************************
// Test Name & Class Name : TC_02_Load_Mul_Tariff_Pages
// Description: After navigating to DSL page with given data,perform given validation on the page 
//            			 where all tariffs are listed
// Data used : Area code: 030 , Bandwidth Option: 100 Mbit/s
// TC_02_Load_Mul_Tariff_Pages extends Base class : To selected needed browser and
//                                           killing driver instance post execution
// Validations performed: 1.After entering required data and clicking on 'Jetzt vergleichen'
//                         button, needed page with available tariffs are displayed 
//                       2.Total Number of tariffs should be displayed on 'Ermittelte Tarife'
//							section.
//						 3. Only first 20 Tariffs should display on a page
//                       4. After Clicking on button '20 weitere Tarife laden' , 
//							next 20 tariffs displayed
//						 5. Continue to load any additional tariffs until all tariffs have					
//							been displayed
//                       6. 'weitere Tarife laden' button is no longer displayed when all 
//              			 Tariffs are visible
//                       7. The Final 'weitere Tarife laden' button displays 
//                     		the expected number of Tariffs remaining
//********************************************************************************************


package com.verivox.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.verivox.Pages.DSL_searchResults;
import com.verivox.Pages.MainPage;
import com.verivox.base.Base;

@Test
public class TC_02_Load_Mul_Tariff_Pages extends Base {

	
	public void load_Tariff_Pages() throws InterruptedException

	{

		// Creating object of MainPage class and calling it's methods
		//These will help navigating till page that lists the available tariffs for selection

		MainPage mp = new MainPage();
		mp.clickDSL_Btn();
		mp.enterIV_Txt();
		mp.MBPS_Select();
		mp.clickJV_Btn();

		
		// Creating object of DSL_searchResults class and calling it's methods

		DSL_searchResults dsr = new DSL_searchResults();
		
		// This will help script to Explicitly wait for 'Zum Angebot' button to get loaded
		dsr.waitfor_20WTL();
		
		//Validate only first 20 Tariffs are displayed 
		dsr.total_Tarif_Loaded_Count();
		
		//This will check on the number of Tarifs displayed in 'Ermittelte Tarife' section
		dsr.ermittelte_Tarife_Count();
						
		System.out.println("Displaying download speeds:");
		
		// Verify that the weitere Tarife laden button is no longer displayed when all
		// the tariffs are visible
	
		dsr.load20moreRes_Btn_Click();
		Assert.assertTrue(dsr.blnVerify_20moreResBtn_display==false);

		// Verify that the total number of tariffs displayed matches the total listed in
		// the Ermittelte Tarife section

		System.out.println("The number of Tariffs displayed in the Ermittelte Tarife section is: " + dsr.intETC);
		if (dsr.intTDC == dsr.intETC)
		{
		System.out.println("All tarifs are displayed");
		Assert.assertTrue(true, "\nAll tariffs are not displayed");
		
		}
	}

}
