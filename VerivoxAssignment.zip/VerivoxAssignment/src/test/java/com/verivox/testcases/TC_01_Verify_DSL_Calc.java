//***********************************HEADER********************************************************
// Test Name & Class Name : TC_01_Verify_DSL_Calc
// Description: After navigating to DSL page with given data, Selecting Internet tariff   
// Data used : Area code: 030 , Bandwidth Option: 100 Mbit/s
// TC_01_Verify_DSL_Calc extends Base class : To selected needed browser and
//                                           killing driver instance post execution
// Validations performed: 1.After entering required data and clicking on 'Jetzt vergleichen'
//                         button, page with available tariffs are displayed 
//                       2.At least 5 Internet tariffs are displayed
//                       3.The displayed tariffs provide at least 100 Mbit/s download speed

//********************************************************************************************


package com.verivox.testcases;

import static org.testng.Assert.assertTrue;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.verivox.Pages.DSL_searchResults;
import com.verivox.Pages.MainPage;
import com.verivox.base.Base;

@Test
public class TC_01_Verify_DSL_Calc extends Base {


	public void verify_DSL_Calc() throws InterruptedException

	{

		// Creating object of MainPage class and calling it's methods
		MainPage mp = new MainPage();
		mp.clickDSL_Btn();
		mp.enterIV_Txt();
		mp.MBPS_Select();
		mp.clickJV_Btn();

		// Creating object of DSL_searchResults class and calling it's methods
		DSL_searchResults dsr = new DSL_searchResults();
		dsr.waitfor_20WTL();
		dsr.total_Tarif_Loaded_Count();
		
		// Verify that at least 5 internet tariffs are displayed
		if (dsr.intTDC >= 5) {
				System.out.println("More than 5 internet tariffs are displayed");
				Assert.assertTrue(true);
		} else {
				System.out.println("Less than 5 internet tariffs are displayed");
				Assert.assertTrue(false);

		}

		boolean b = dsr.dlSpeed_LandingPage();
		
		// Verify that the displayed tariffs provide at least 100 Mbit/s download speed
		if (b) {
			System.out.println("The displayed tariffs provide at least 100 Mbit/s download speed");
			assertTrue(true);
		} else {
			System.out.println("The displayed tariffs don't provide at least 100 Mbit/s download speed");
			assertTrue(false);
			
		}
		
	}
}
